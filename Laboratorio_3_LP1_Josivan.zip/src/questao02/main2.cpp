#include <iostream>

#include "agencia.h"

int main(int argc, char const *argv[])
{
	std::cout << "Banco\n";


	return 0;
}