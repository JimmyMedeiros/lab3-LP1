##########################################
# MENSAGEM DO TEOBALDO
##########################################

Caro amigo, nem sei por onde começar. Soube do desastre que foi a avaliação, mas eu realmente tive que viajar e não deu tempo de completar as implementações.

A propósito, acabo de notar que estou atrasado para outra viagem...

Hey! Posso te pedir mais um GRANDE favor? Completa esse código para mim?!

Não se esqueça de:
* Completar a implementação das classes
* Documentar o código usando Doxygen
* Criar um makefile apropiado
* Alterar o main para testar toda a implementação

IMPORTANTE:
* Não permita incluir na lista produtos com o mesmo código
* Confesso que apenas reproduzi a sobrecarga do operador de inserção na classe Produto, mas não sei bem o que fiz. O que eu realmente não entendi foi como, mesmo eu não tendo sobrecarregado o operador de inserção na classe Fruta, ainda consigo imprimir os dados de um objeto desta classe usando este operador! Que loucura! Por isso, preciso que você explique isso em um ou dois parágrafos para eu enviar ao professor.
* Outra parte que eu fiz, mas não sei bem a razão, foi declarar o método destrutor da classe Produto como virtual. Advinha?! Eu também preciso explicar isso ao professor. Conto com sua ajuda!

Fico te devendo mais esta!

Tenho que ir.

Teobaldo
