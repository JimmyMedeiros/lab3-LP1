var searchData=
[
  ['universidade_20federal_20do_20rio_20grande_20do_20norte_20_3cbr_3e_20instituito_20metrópole_20digital',['Universidade Federal do Rio Grande do Norte &lt;br&gt; Instituito Metrópole Digital',['../md_README.html',1,'']]]
];
