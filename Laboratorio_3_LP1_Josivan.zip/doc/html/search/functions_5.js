var searchData=
[
  ['roupa',['Roupa',['../classRoupa.html#a0b8186c1c35089bebd88c8a3d0acf74b',1,'Roupa::Roupa()'],['../classRoupa.html#aae814e79a5bae6245e6bc60edd4b7c37',1,'Roupa::Roupa(std::string _codigo, std::string _descricao, short _preco, std::string _marca, char _sexo, std::string _tamanho)']]]
];
