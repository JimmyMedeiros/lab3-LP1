var searchData=
[
  ['setcodbarras',['setCodBarras',['../classProduto.html#a8f8e7d58e53d3f175bc41b2481dbf477',1,'Produto']]],
  ['setdescricao',['setDescricao',['../classProduto.html#a35b8ac377821ca2197becf75e1063509',1,'Produto']]],
  ['setpreco',['setPreco',['../classProduto.html#a207ec4b3438d376227ca3053a14669cf',1,'Produto']]]
];
