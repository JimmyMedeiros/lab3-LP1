var indexSectionsWithContent =
{
  0: "abcdefglmprstu~",
  1: "abcfpr",
  2: "abcmp",
  3: "acdegrst~",
  4: "m",
  5: "lru"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Estruturas de dados",
  2: "Ficheiros",
  3: "Funções",
  4: "Variáveis",
  5: "Páginas"
};

