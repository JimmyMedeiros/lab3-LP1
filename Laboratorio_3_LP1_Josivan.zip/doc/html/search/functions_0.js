var searchData=
[
  ['agencia',['Agencia',['../classAgencia.html#a11530916e5f2f82ec0778b82a0fffbfd',1,'Agencia::Agencia()'],['../classAgencia.html#a90e49d9c3bb150360490557477f12c45',1,'Agencia::Agencia(num_type _numero)']]]
];
