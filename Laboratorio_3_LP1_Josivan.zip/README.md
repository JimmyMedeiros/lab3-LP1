#### Universidade Federal do Rio Grande do Norte <br> Instituito Metrópole Digital
<br>Aluno: Josivan Medeiros da Silva Gois
<br>Matrícula: 20160147626
<br>Professor: Silvio Costa Sampaio

# Laboratório 3 - Linguagem de Programação 1
Terceiro laboratório da disciplina de Linguagem de Programação 1 do curso de Tecnologia da Informação. 

@TODO

## Intruções de Compição:
- make all:<br>
Compila todos os programas
- make questaon:<br>
Compila o programa n, sendo n o número do programa que pode ser: 01, 02 ou 03
- make debug:<BR>
Compila os programas em modo de depuração
- make doxy:<BR>
Gera na pasta doc a documentação em html
- make clean:<BR>
Apaga os arquivos das bastas bin e build

### Programa 01

@TODO

### Programa 02

@TODO
